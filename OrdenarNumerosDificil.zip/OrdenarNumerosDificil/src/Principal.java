public class Principal {
    public static void main(String[] args) {
        // Definimos el arreglo de números que queremos ordenar
        int[] numbers = {4, 3, 2, 1, 6, 5}; 
        int n = numbers.length; // Obtenemos la longitud del arreglo
        
        boolean swapped; // Esta variable indicará si hubo un intercambio en una pasada

        // El primer bucle controla cuántas pasadas hacemos sobre el arreglo
        for (int i = 0; i < n; i++) {
            swapped = false; // Reiniciamos la variable a false al comienzo de cada pasada
            
            // El segundo bucle compara los elementos adyacentes en el arreglo
            // Cada vez que hacemos una pasada, ya no necesitamos revisar los últimos elementos que ya están ordenados
            for (int j = 0; j < n - i - 1; j++) {
                // Si el número en la posición actual es mayor que el siguiente, los intercambiamos
                if (numbers[j] > numbers[j + 1]) {
                    // Guardamos el valor actual en una variable temporal
                    int temp = numbers[j];
                    // Movemos el valor más pequeño a la posición actual
                    numbers[j] = numbers[j + 1];
                    // Colocamos el valor más grande en la siguiente posición
                    numbers[j + 1] = temp;
                    
                    // Marcamos que hubo un intercambio
                    swapped = true;

                    // Mostramos el estado actual del arreglo después de cada intercambio
                    for (int num : numbers) {
                        System.out.print(num + " "); // Imprime cada número del arreglo seguido de un espacio
                    }
                    System.out.println(); // Salto de línea para que cada estado se vea en una línea nueva
                }
            }
            
            // Si no hubo intercambios en una pasada, significa que el arreglo ya está ordenado
            // y podemos terminar el bucle antes de completar todas las pasadas, haciendo que el algoritmo sea más eficiente
            if (!swapped) break;
        }
    }
}


/*
 * Mi código es optimo porque cuenta con una simplifidad ya que es fácil de entender y de implementar, 
 * además de ser muy visual ya que  observamos cada paso del arreglo tras cada intercambio. Cuenta con una 
 * limitación y es que no es eficiente para grandes cantidades de datos; 
 * algoritmos como QuickSort o MergeSort son mejores en esos casos. 
 */
