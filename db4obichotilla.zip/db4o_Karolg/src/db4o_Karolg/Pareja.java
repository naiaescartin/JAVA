package db4o_Karolg;

public class Pareja {

	private int id_pareja;
    private String nombre_pareja;
    private int duracion_relacion;
    
	public Pareja(int id_pareja, String nombre_pareja, int duracion_relacion) {
		super();
		this.id_pareja = id_pareja;
		this.nombre_pareja = nombre_pareja;
		this.duracion_relacion = duracion_relacion;
	}

	public int getId_pareja() {
		return id_pareja;
	}

	public void setId_pareja(int id_pareja) {
		this.id_pareja = id_pareja;
	}

	public String getNombre_pareja() {
		return nombre_pareja;
	}

	public void setNombre_pareja(String nombre_pareja) {
		this.nombre_pareja = nombre_pareja;
	}

	public int getDuracion_relacion() {
		return duracion_relacion;
	}

	public void setDuracion_relacion(int duracion_relacion) {
		this.duracion_relacion = duracion_relacion;
	}
 
    
	
	
}
