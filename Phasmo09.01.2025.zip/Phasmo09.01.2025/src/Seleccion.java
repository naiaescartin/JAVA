import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.ImageIcon;

public class Seleccion extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Seleccion frame = new Seleccion();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public Seleccion() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 450, 300);
        contentPane = new JPanel();
        contentPane.setBackground(new Color(0, 0, 0));
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

        setContentPane(contentPane);
        contentPane.setLayout(null);

      
        JButton btnUnJugador = new JButton("Un jugador");
        btnUnJugador.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                UnJugador unJugador = new UnJugador(); 
                unJugador.setVisible(true); 
                dispose(); 
            }
        });
        btnUnJugador.setBackground(new Color(255, 255, 255));
        btnUnJugador.setForeground(new Color(0, 0, 0));
        btnUnJugador.setFont(new Font("Segoe Script", Font.BOLD, 17));
        btnUnJugador.setBounds(25, 25, 158, 39);
        contentPane.add(btnUnJugador);

       
        JButton btnMultijugador = new JButton("Multijugador");
        btnMultijugador.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Multijugador multijugador = new Multijugador(); 
                multijugador.setVisible(true); 
                dispose(); 
            }
        });
        btnMultijugador.setBackground(new Color(255, 255, 255));
        btnMultijugador.setFont(new Font("Segoe Script", Font.BOLD, 17));
        btnMultijugador.setBounds(25, 78, 158, 39);
        contentPane.add(btnMultijugador);

        
        JButton btnInventario = new JButton("Inventario");
        btnInventario.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Tienda inventario = new Tienda(); 
                inventario.setVisible(true); 
                dispose(); 
            }
        });
        btnInventario.setFont(new Font("Segoe Script", Font.BOLD, 17));
        btnInventario.setBackground(new Color(255, 255, 255));
        btnInventario.setBounds(25, 127, 158, 36);
        contentPane.add(btnInventario);

        
        JButton btnTienda = new JButton("Tienda");
        btnTienda.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Tienda tienda = new Tienda(); 
                tienda.setVisible(true); 
                dispose(); 
            }
        });
        btnTienda.setBackground(new Color(255, 255, 255));
        btnTienda.setFont(new Font("Segoe Script", Font.BOLD, 17));
        btnTienda.setBounds(25, 173, 158, 36);
        contentPane.add(btnTienda);

       
        JButton btnSalir = new JButton("Salir");
        btnSalir.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.exit(0); 
            }
        });
        btnSalir.setFont(new Font("Segoe Script", Font.BOLD, 17));
        btnSalir.setBackground(new Color(255, 255, 255));
        btnSalir.setBounds(25, 219, 158, 34);
        contentPane.add(btnSalir);
        
        JLabel lblNewLabel = new JLabel("New label");
        lblNewLabel.setIcon(new ImageIcon("C:\\Users\\Naia\\Downloads\\Captura de pantalla 2024-12-05 102039 (1).png"));
        lblNewLabel.setBounds(310, 10, 116, 107);
        contentPane.add(lblNewLabel);
        
        JLabel lblNewLabel_1 = new JLabel("New label");
        lblNewLabel_1.setIcon(new ImageIcon("C:\\Users\\Naia\\Downloads\\semanales (1).png"));
        lblNewLabel_1.setBounds(206, 108, 94, 130);
        contentPane.add(lblNewLabel_1);
        
        JLabel lblNewLabel_2 = new JLabel("New label");
        lblNewLabel_2.setIcon(new ImageIcon("C:\\Users\\Naia\\Downloads\\misionesdiarias (1).png"));
        lblNewLabel_2.setBounds(320, 120, 94, 107);
        contentPane.add(lblNewLabel_2);
    }
}
