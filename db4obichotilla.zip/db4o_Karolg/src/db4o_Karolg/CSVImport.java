package db4o_Karolg;

import com.db4o.Db4o;
import com.db4o.ObjectContainer;
import com.db4o.ObjectSet;
import com.db4o.query.Query;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class CSVImport {

    private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd");

    public static void importarGirasDesdeCSV(String archivoCSV, ObjectContainer db) {
        String linea;
        String separador = ",";

        try (BufferedReader br = new BufferedReader(new FileReader(archivoCSV))) {
            br.readLine(); 
            while ((linea = br.readLine()) != null) {
                String[] datos = linea.split(separador);

                if (datos.length >= 5) {
                    int id = Integer.parseInt(datos[0].trim());
                    String nombre = datos[1].trim();
                    Date fechaInicio = convertirFecha(datos[2].trim());
                    Date fechaFin = convertirFecha(datos[3].trim());
                    int numConciertos = Integer.parseInt(datos[4].trim());

                    Gira gira = new Gira(id, nombre, fechaInicio, fechaFin, numConciertos, new ArrayList<>());
                    db.store(gira);
                    System.out.println("Gira importada: " + gira.getNombre());
                }
            }
        } catch (IOException | ParseException e) {
            e.printStackTrace();
        }
    }

    
    public static void importarAlbumsDesdeCSV(String archivoCSV, ObjectContainer db, List<Gira> giras) {
        String linea;
        String separador = ",";

        try (BufferedReader br = new BufferedReader(new FileReader(archivoCSV))) {
            br.readLine();
            while ((linea = br.readLine()) != null) {
                String[] datos = linea.split(separador);

                if (datos.length >= 4) {
                    int id = Integer.parseInt(datos[0].trim());
                    String titulo = datos[1].trim();
                    Date fechaLanzamiento = convertirFecha(datos[2].trim());
                    int idGira = Integer.parseInt(datos[3].trim());

                    Gira gira = giras.stream().filter(g -> g.getId_gira() == idGira).findFirst().orElse(null);
                    Album album = new Album(id, titulo, fechaLanzamiento, gira, new ArrayList<>());
                    db.store(album);
                    System.out.println("Álbum importado: " + album.getTitulo_album());
                }
            }
        } catch (IOException | ParseException e) {
            e.printStackTrace();
        }
    }

    
    public static void importarCancionesDesdeCSV(String archivoCSV, ObjectContainer db, List<Album> albums) {
        String linea;
        String separador = ",";

        try (BufferedReader br = new BufferedReader(new FileReader(archivoCSV))) {
            br.readLine(); 
            while ((linea = br.readLine()) != null) {
                String[] datos = linea.split(separador);

                if (datos.length >= 5) {
                    int id = Integer.parseInt(datos[0].trim());
                    String titulo = datos[1].trim();
                    int duracion = Integer.parseInt(datos[2].trim());
                    String genero = datos[3].trim();
                    int idAlbum = Integer.parseInt(datos[4].trim());

                    Album album = albums.stream().filter(a -> a.getId_album() == idAlbum).findFirst().orElse(null);
                    CancionTop cancion = new CancionTop(id, titulo, duracion, genero, album, new ArrayList<>());
                    db.store(cancion);
                    System.out.println("Canción importada: " + cancion.getTitulo());
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void importarRedesSocialesDesdeCSV(String archivoCSV, ObjectContainer db) {
        String linea;
        String separador = ",";

        try (BufferedReader br = new BufferedReader(new FileReader(archivoCSV))) {
            br.readLine(); 
            while ((linea = br.readLine()) != null) {
                String[] datos = linea.split(separador);

                if (datos.length >= 3) {
                    int id = Integer.parseInt(datos[0].trim());
                    String plataforma = datos[1].trim();
                    int seguidores = Integer.parseInt(datos[2].trim());

                    RedSocial redSocial = new RedSocial(id, plataforma, seguidores);
                    db.store(redSocial);
                    System.out.println("Red Social importada: " + redSocial.getPlataforma());
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void importarParejasDesdeCSV(String archivoCSV, ObjectContainer db) {
        String linea;
        String separador = ",";

        try (BufferedReader br = new BufferedReader(new FileReader(archivoCSV))) {
            br.readLine(); 
            while ((linea = br.readLine()) != null) {
                String[] datos = linea.split(separador);

                if (datos.length >= 3) {
                    int id = Integer.parseInt(datos[0].trim());
                    String nombre = datos[1].trim();
                    int duracion = Integer.parseInt(datos[2].trim());

                    Pareja pareja = new Pareja(id, nombre, duracion);
                    db.store(pareja);
                    System.out.println("Pareja importada: " + pareja.getNombre_pareja());
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void importarPremiosDesdeCSV(String archivoCSV, ObjectContainer db) {
        String linea;
        String separador = ",";

        try (BufferedReader br = new BufferedReader(new FileReader(archivoCSV))) {
            br.readLine();
            while ((linea = br.readLine()) != null) {
                String[] datos = linea.split(separador);

                if (datos.length >= 5) {
                    int id = Integer.parseInt(datos[0].trim());
                    String nombre = datos[1].trim();
                    String categoria = datos[2].trim();
                    int año = Integer.parseInt(datos[3].trim());
                    String resultado = datos[4].trim();

                    Premio premio = new Premio(id, nombre, categoria, año, resultado);
                    db.store(premio);
                    System.out.println("Premio importado: " + premio.getNombre_premio());
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void importarColaboracionesDesdeCSV(String archivoCSV, ObjectContainer db, List<CancionTop> canciones) {
        String linea;
        String separador = ",";

        try (BufferedReader br = new BufferedReader(new FileReader(archivoCSV))) {
            br.readLine(); 
            while ((linea = br.readLine()) != null) {
                String[] datos = linea.split(separador);

                if (datos.length >= 3) {
                    int id = Integer.parseInt(datos[0].trim());
                    int numColaboraciones = Integer.parseInt(datos[1].trim());
                    int idCancion = Integer.parseInt(datos[2].trim());

                    CancionTop cancion = canciones.stream().filter(c -> c.getId_cancion() == idCancion).findFirst().orElse(null);
                    Colaboracion colaboracion = new Colaboracion(id, numColaboraciones, cancion);
                    db.store(colaboracion);
                    System.out.println("Colaboración importada: " + colaboracion.getId_colaboracion());
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public static void consultarTodasLasGiras(ObjectContainer db) {
        Query query = db.query();
        query.constrain(Gira.class);
        ObjectSet<Gira> result = query.execute();

        System.out.println("Todas las giras:");
        while (result.hasNext()) {
            Gira gira = result.next();
            System.out.println(gira);
        }
    }

    public static void consultarAlbumsDeGira(ObjectContainer db, String nombreGira) {
        Query query = db.query();
        query.constrain(Album.class); 
        query.descend("id_giras").descend("nombre").constrain(nombreGira); 

        ObjectSet<Album> result = query.execute();

        System.out.println("Álbumes de la gira '" + nombreGira + "':");
        while (result.hasNext()) {
            Album album = result.next();
            System.out.println(album);
        }
    }
    
    public static void consultarCancionesPorGenero(ObjectContainer db, String genero) {
        Query query = db.query();
        query.constrain(CancionTop.class);
        query.descend("genero").constrain(genero); 

        ObjectSet<CancionTop> result = query.execute();

        System.out.println("Canciones de género '" + genero + "':");
        while (result.hasNext()) {
            CancionTop cancion = result.next();
            System.out.println(cancion);
        }
    }
    
    public static void consultarRedesSocialesConMasSeguidores(ObjectContainer db, int seguidoresMinimos) {
        Query query = db.query();
        query.constrain(RedSocial.class); 
        query.descend("seguidores").constrain(seguidoresMinimos).greater(); 

        ObjectSet<RedSocial> result = query.execute();

        System.out.println("Redes sociales con más de " + seguidoresMinimos + " seguidores:");
        while (result.hasNext()) {
            RedSocial redSocial = result.next();
            System.out.println(redSocial);
        }
    }
    
    public static void consultarPremiosGanadosEnAnio(ObjectContainer db, int año) {
        Query query = db.query();
        query.constrain(Premio.class);
        query.descend("año").constrain(año); 
        query.descend("resultado").constrain("Ganadora"); 

        ObjectSet<Premio> result = query.execute();

        System.out.println("Premios ganados en el año " + año + ":");
        while (result.hasNext()) {
            Premio premio = result.next();
            System.out.println(premio);
        }
    }
    
    private static Date convertirFecha(String fecha) throws ParseException {
        return DATE_FORMAT.parse(fecha);
    }

    public static void main(String[] args) {
        ObjectContainer db = Db4o.openFile("db4o");

        try {
            importarGirasDesdeCSV("giras.csv", db);
            List<Gira> giras = db.query(Gira.class);

            importarAlbumsDesdeCSV("albums.csv", db, giras);
            List<Album> albums = db.query(Album.class);

            importarCancionesDesdeCSV("canciones.csv", db, albums);
            List<CancionTop> canciones = db.query(CancionTop.class);

            importarRedesSocialesDesdeCSV("redes_sociales.csv", db);

            importarParejasDesdeCSV("parejas.csv", db);

            importarPremiosDesdeCSV("premios.csv", db);

            importarColaboracionesDesdeCSV("colaboraciones.csv", db, canciones);
            
            consultarTodasLasGiras(db);
            consultarAlbumsDeGira(db, "Bichota Tour");
            consultarCancionesPorGenero(db, "Reggaeton");
            consultarRedesSocialesConMasSeguidores(db, 10000000);
            consultarPremiosGanadosEnAnio(db, 2020);

        } finally {
            db.close();
        }
    }
}