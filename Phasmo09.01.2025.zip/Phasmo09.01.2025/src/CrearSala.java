import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JButton;

public class CrearSala extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CrearSala frame = new CrearSala();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CrearSala() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 0, 0));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Privada");
		lblNewLabel.setForeground(new Color(255, 255, 255));
		lblNewLabel.setFont(new Font("Segoe Script", Font.BOLD, 13));
		lblNewLabel.setBounds(153, 47, 73, 24);
		contentPane.add(lblNewLabel);
		
		JCheckBox chckbxNewCheckBox = new JCheckBox("");
		chckbxNewCheckBox.setBackground(new Color(0, 0, 0));
		chckbxNewCheckBox.setBounds(223, 47, 21, 21);
		contentPane.add(chckbxNewCheckBox);
		
		JLabel lblNewLabel_1 = new JLabel("Máximo de jugadores");
		lblNewLabel_1.setForeground(new Color(255, 255, 255));
		lblNewLabel_1.setBackground(new Color(255, 255, 255));
		lblNewLabel_1.setFont(new Font("Segoe Script", Font.BOLD, 13));
		lblNewLabel_1.setBounds(99, 95, 185, 25);
		contentPane.add(lblNewLabel_1);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setFont(new Font("Segoe Script", Font.BOLD, 10));
		comboBox.setMaximumRowCount(4);
		comboBox.setBounds(270, 97, 41, 24);
		contentPane.add(comboBox);
		
		for (int i = 1; i <= 4; i++) {
            comboBox.addItem(i);
        }

        contentPane.add(comboBox);
		
		JButton btnNewButton = new JButton("Crear Sala");
		btnNewButton.setFont(new Font("Segoe Script", Font.BOLD, 13));
		btnNewButton.setBounds(147, 151, 120, 24);
		contentPane.add(btnNewButton);
		
		
		JButton btnVolver = new JButton("Volver");
		btnVolver.setFont(new Font("Segoe Script", Font.BOLD, 11));
		btnVolver.setBounds(353, 229, 73, 24);
		contentPane.add(btnVolver);
		
		btnVolver.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose(); 
                Multijugador multijugador = new Multijugador();
                multijugador.setVisible(true); 
            }
        });
		
		btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose(); 
                Jugar jugar = new Jugar();
                jugar.setVisible(true); 
            }
        });
		
	}
}
