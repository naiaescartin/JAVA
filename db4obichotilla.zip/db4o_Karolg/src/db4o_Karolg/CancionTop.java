package db4o_Karolg;
import java.util.List;
public class CancionTop {

	private int id_cancion;
    private String titulo;
    private int duracion;
    private String genero;
    private Album id_album;
    private List<Colaboracion> colaboraciones;
    
	public CancionTop(int id_cancion, String titulo, int duracion, String genero, Album id_album,
			List<Colaboracion> colaboraciones) {
		super();
		this.id_cancion = id_cancion;
		this.titulo = titulo;
		this.duracion = duracion;
		this.genero = genero;
		this.id_album = id_album;
		this.colaboraciones = colaboraciones;
	}

	public int getId_cancion() {
		return id_cancion;
	}

	public void setId_cancion(int id_cancion) {
		this.id_cancion = id_cancion;
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public int getDuracion() {
		return duracion;
	}

	public void setDuracion(int duracion) {
		this.duracion = duracion;
	}

	public String getGenero() {
		return genero;
	}

	public void setGenero(String genero) {
		this.genero = genero;
	}

	public Album getId_album() {
		return id_album;
	}

	public void setId_album(Album id_album) {
		this.id_album = id_album;
	}

	public List<Colaboracion> getColaboraciones() {
		return colaboraciones;
	}

	public void setColaboraciones(List<Colaboracion> colaboraciones) {
		this.colaboraciones = colaboraciones;
	}
	@Override
	public String toString() {
	    return "Canción: " + titulo + " (Duración: " + duracion + "s, Género: " + genero + ")";
	}
}
