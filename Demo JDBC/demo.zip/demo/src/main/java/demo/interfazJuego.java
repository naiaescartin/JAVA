package demo;

import java.io.FileInputStream;
import java.io.IOException;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class interfazJuego extends Application {

    @Override
    public void start(Stage stage) throws IOException {
        // Configuración de los botones
        Button superviviente = new Button("Superviviente");
        Button asesino = new Button("Asesino");
        Button salir = new Button("Salir");

        
        //estilo de los botones
        String buttonStyle = "-fx-text-fill: white; " +
                             "-fx-font-size: 35px; " +  
                             "-fx-font-family: 'Arial Black'; " +   
                             "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.75), 4, 0.5, 0, 1); " + 
                             "-fx-background-color: transparent;";  

        String hoverStyle = "-fx-text-fill: red; " + 
                            "-fx-font-size: 35px; " +
                            "-fx-font-family: 'Arial Black'; " +
                            "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.75), 4, 0.5, 0, 1); " +
                            "-fx-background-color: transparent;";

        superviviente.setStyle(buttonStyle);
        asesino.setStyle(buttonStyle);
        salir.setStyle(buttonStyle);

        //Añadir eventos de ratón para cambiar el estilo al pasar sobre los botones
        superviviente.setOnMouseEntered(e -> superviviente.setStyle(hoverStyle));
        superviviente.setOnMouseExited(e -> superviviente.setStyle(buttonStyle));

        asesino.setOnMouseEntered(e -> asesino.setStyle(hoverStyle));
        asesino.setOnMouseExited(e -> asesino.setStyle(buttonStyle));

        salir.setOnMouseEntered(e -> salir.setStyle(hoverStyle));
        salir.setOnMouseExited(e -> salir.setStyle(buttonStyle));

        //Cargar la imagen desde el archivo local
        Image backgroundImage = new Image(new FileInputStream("C:/Interfaces/java2DAM/Demo JDBC/demo/src/main/java/demo/dbd5.jpg"));

        //Crear el VBox para los botones y configurarlos verticalmente
        VBox buttonBox = new VBox(10); // 10px de separación entre botones
        buttonBox.setPadding(new Insets(20)); // Añadir un padding de 20px
        buttonBox.setAlignment(Pos.TOP_LEFT); // Alinear a la izquierda y arriba
        buttonBox.getChildren().addAll(superviviente, asesino, salir); // Añadir los botones al VBox

        //Crear un GridPane para agregar los elementos
        GridPane root = new GridPane();
        root.setPadding(new Insets(10));

        //Crear una escena y añadir el GridPane
        Scene scene = new Scene(root, 800, 600);

        //Establecer el fondo del GridPane
        setBackgroundImage(root, backgroundImage, scene.getWidth(), scene.getHeight());

        //Añadir los botones al GridPane
        root.add(buttonBox, 0, 0);

        //Listener para cambiar el fondo cuando cambie el tamaño de la ventana
        scene.widthProperty().addListener((obs, oldVal, newVal) -> {
            setBackgroundImage(root, backgroundImage, scene.getWidth(), scene.getHeight());
        });

        scene.heightProperty().addListener((obs, oldVal, newVal) -> {
            setBackgroundImage(root, backgroundImage, scene.getWidth(), scene.getHeight());
        });

        
        salir.setOnAction(e -> {
            stage.close(); //Cerrar la aplicación
        });

        //Configuración de la ventana principal (Stage)
        stage.setTitle("Dead by Daylight");
        stage.setScene(scene);
        stage.setFullScreen(true);  //Pantalla completa
        stage.show();
    }

    //Imagen de fondo
    private void setBackgroundImage(GridPane root, Image backgroundImage, double width, double height) {
        BackgroundSize backgroundSize = new BackgroundSize(width, height, false, false, false, false);
        BackgroundImage bgImage = new BackgroundImage(
                backgroundImage,
                BackgroundRepeat.NO_REPEAT,
                BackgroundRepeat.NO_REPEAT,
                BackgroundPosition.CENTER,
                backgroundSize
        );
        root.setBackground(new Background(bgImage));
    }

    

    public static void main(String[] args) {
        launch(args);
    }
}
