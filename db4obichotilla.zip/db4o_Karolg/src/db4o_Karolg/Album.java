package db4o_Karolg;

import java.util.Date;
import java.util.List;

public class Album {

	private int id_album;
    private String titulo_album;
    private Date fecha_lanzamiento;
    private Gira id_giras;
    private List<CancionTop> canciones;

	public Album(int id_album, String titulo_album, Date fecha_lanzamiento, Gira id_giras, List<CancionTop> canciones) {
		super();
		this.id_album = id_album;
		this.titulo_album = titulo_album;
		this.fecha_lanzamiento = fecha_lanzamiento;
		this.id_giras = id_giras;
		this.canciones = canciones;
	}

	public int getId_album() {
		return id_album;
	}

	public void setId_album(int id_album) {
		this.id_album = id_album;
	}

	public String getTitulo_album() {
		return titulo_album;
	}

	public void setTitulo_album(String titulo_album) {
		this.titulo_album = titulo_album;
	}

	public Date getFecha_lanzamiento() {
		return fecha_lanzamiento;
	}

	public void setFecha_lanzamiento(Date fecha_lanzamiento) {
		this.fecha_lanzamiento = fecha_lanzamiento;
	}

	public Gira getId_giras() {
		return id_giras;
	}

	public void setId_giras(Gira id_giras) {
		this.id_giras = id_giras;
	}

	public List<CancionTop> getCanciones() {
		return canciones;
	}

	public void setCanciones(List<CancionTop> canciones) {
		this.canciones = canciones;
	}
	
	@Override
	public String toString() {
	    return "Álbum: " + titulo_album + " (Lanzamiento: " + fecha_lanzamiento + ")";
	}
}
