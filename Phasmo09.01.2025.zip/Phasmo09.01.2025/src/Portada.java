import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

public class Portada extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                Portada frame = new Portada(); 
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public Portada() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 450, 300);
        contentPane = new JPanel();
        contentPane.setBackground(new Color(0, 0, 0));
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JButton btnNewButton = new JButton("Jugar");
        btnNewButton.setBackground(new Color(255, 255, 255));
        btnNewButton.setFont(new Font("Segoe Script", Font.BOLD, 12));
        btnNewButton.setBounds(23, 113, 91, 29);
        contentPane.add(btnNewButton);
        
        TextAreaconGuardar textAreaconGuardar = new TextAreaconGuardar();
        textAreaconGuardar.setBounds(46, 92, 340, 214);
        contentPane.add(textAreaconGuardar);
                
                        JLabel lblNewLabel = new JLabel("PHASMOPHOBIA");
                        lblNewLabel.setBounds(0, 0, 369, 129);
                        contentPane.add(lblNewLabel);
                        lblNewLabel.setForeground(new Color(255, 255, 255));
                        lblNewLabel.setFont(new Font("Segoe Script", Font.BOLD, 36));

        btnNewButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Seleccion seleccion = new Seleccion();
                seleccion.setVisible(true);
                dispose(); 
            }
        });
        TextAreaconGuardar guardar;
    }
}
