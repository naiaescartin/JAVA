import java.awt.EventQueue;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Multijugador extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Multijugador frame = new Multijugador();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public Multijugador() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 450, 300);
        contentPane = new JPanel();
        contentPane.setBackground(new Color(0, 0, 0));
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lblNewLabel = new JLabel("Multijugador");
        lblNewLabel.setForeground(new Color(255, 255, 255));
        lblNewLabel.setFont(new Font("Segoe Script", Font.BOLD, 16));
        lblNewLabel.setBounds(168, 0, 116, 65);
        contentPane.add(lblNewLabel);

        JButton btnSalir = new JButton("Salir");
        btnSalir.setFont(new Font("Segoe Script", Font.BOLD, 12));
        btnSalir.setBounds(309, 236, 99, 17);
        contentPane.add(btnSalir);

        JButton btnCrearSala = new JButton("Crear Sala");
        btnCrearSala.setFont(new Font("Segoe Script", Font.BOLD, 13));
        btnCrearSala.setBounds(29, 110, 116, 17);
        contentPane.add(btnCrearSala);

        JButton btnTienda = new JButton("Tienda");
        btnTienda.setFont(new Font("Segoe Script", Font.BOLD, 12));
        btnTienda.setBounds(309, 209, 99, 17);
        contentPane.add(btnTienda);

        JButton btnInventario = new JButton("Inventario");
        btnInventario.setFont(new Font("Segoe Script", Font.BOLD, 12));
        btnInventario.setBounds(309, 182, 99, 17);
        contentPane.add(btnInventario);

        JButton btnUnirteSala = new JButton("Unirte Sala");
        btnUnirteSala.setFont(new Font("Segoe Script", Font.BOLD, 13));
        btnUnirteSala.setBounds(29, 137, 116, 17);
        contentPane.add(btnUnirteSala);
        
        JLabel lblNewLabel_1 = new JLabel("New label");
        lblNewLabel_1.setIcon(new ImageIcon("C:\\Users\\Naia\\Downloads\\Captura de pantalla 2024-12-05 102039 (1).png"));
        lblNewLabel_1.setBounds(274, 48, 133, 116);
        contentPane.add(lblNewLabel_1);
        
        JLabel lblNewLabel_2 = new JLabel("New label");
        lblNewLabel_2.setIcon(new ImageIcon("C:\\Users\\Naia\\Downloads\\81PKOcxidaL._AC_UF894,1000_QL80_ (1).jpg"));
        lblNewLabel_2.setBounds(10, 60, 416, 193);
        contentPane.add(lblNewLabel_2);

        
        btnSalir.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose(); 
                Seleccion seleccion = new Seleccion();
                seleccion.setVisible(true); 
            }
        });

        
        btnTienda.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose(); 
                Tienda tienda = new Tienda();
                tienda.setVisible(true); 
            }
        });

       
        btnInventario.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose(); 
                Tienda tienda = new Tienda();
                tienda.setVisible(true); 
            }
        });
        
        btnCrearSala.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose(); 
                CrearSala crearsala = new CrearSala();
                crearsala.setVisible(true); 
            }
        });
        
        
    }
}
