import java.util.Scanner;

public class DibujoLetras {
	
	/*
	 * Primero mi programa va a mostrar por pantalla un mensaje al usuario en el que pida a este introducir un caracter no alfanumérico.
	 * Después va a pedir que se introduzca un número mayor o igual que 9 y si no lo es, mostrar el error y finalizar programa.
	 * Y por último el usuario nos va a introducir una de las letras a dibujar, mostradas por consola a través de un array y si no está
	 * dicha letra dentro del array, el programa finalizará.
	 * Para ello voy a crear un switch que se encargue de cada uno de los casos, es decir que si se introduce por ejemplo la letra 'V' nos haga
	 * el case 'V' dibujando la letra 'V'.
	 * 
	 * PARA DIBUJAR LA LETRA E:
	 * Para dibujar la letra E, el usuario me introducirá la altura de la letra y para realizar las tres líneas de la 'E'  la altura
	 * entre  2, desde el primer caracter y el ultimo de la altura. Despues volveremos a dividir entre dos la altura para hallar el punto medio
	 * para dibujar la ultima linea.
	 * PARA DIBUJAR LA LETRA T:
	 * Dibujaremos una línea horizontal en la parte superior y luego le añadiremos la columna de en medio con 
	 * num/2 para que se realice en la posicion de en medio
	 * PARA DIBUJAR LA LETRA I:
	 * Hare un bucle que controle la fila que sea el numero ingresado por el usuario, 
	 * luego añadiremos las lineas de arriba y abajo haciendo dicha altura (num) entre 2
	 * PARA DIBUJAR LA LETRA P:
	 * Primero verificaremos si el numero es par o impar y haremos que sea par, para poder tener el centro bien definido. Para imprimir la primera linea de la T lo haremos mediante la posicion -1 y añadiremos dicho caracter. 
	 * Las lineas intermedias sacaremos un largura diviendo num/2 y anidaremos un bucle for para calcular los espacios
	 * PARA DIBUJAR LA LETRA H:
	 * Para realizar la H pondremos el numero introducido por el usuario como altura y sacaremos el medio, y dibujaremos el mismo numero 
	 * de manera horizontal y dejaremos el numero de espacios como caracter introducido para unirlo con la otra linea vertical
	 * PARA DIBUJAR LA LETRA L:
	 * Primero imprimiremos la linea vertical con el numero introducido, 
	 * despues realizaremos la linea inferior con una posicion -1 para que se imprima en la posicion deseada.
	 * PARA DIBUJAR LA LETRA V:
	 *  Para hacer la primera fila debemos de utilizar de separacion entre una letra y la otra el numero de espacios como numero haya introducido
	 * y despues restarle dos a dicho espacio para generar el hueco entre las dos siguientes letras que se colocarian en la linea de debajo
	 * hasta finalmente llegar a un espacio de separacion. La ultima linea sera dibujada sacando el centro (-1 al numero
	 * introducido) y poniendo ese unico caracter una vez.
	 * PARA DIBUJAR LA LETRA D:
	 * Primero creamos la linea superior dicha linea sera num-_ num/9. Imprimimos un caracter en la posicion incial  y crearemos otro bucle para calcular los espacios en blanco de cada linea. 
	 * Para realizar la parte inferior pondre lo mismo que en la superior, num - num/9
	 * PARA DIBUJAR LA LETRA A:
	 * Para hacer la A me hare la V previamente hecha pero de manera invertida y para sacar la linea horizontal de en medio
	 * sacare el medio de la misma manera que he hecho para hallar la H
	 * PARA DIBUJAR LA LETRA O:
	 * La logica que voy a seguir es: el numero introducido por el usuario será el numero de caracteres que haya tanto de anchura como de largura.
	 * Y para ello calcularé si nos encontramos en el centro o en uno de los extremos y a partir de ahi me imprimira un caracter o bien un espacio.
	 * PARA DIBUJAR LA LETRA U: Seguire la misma logica que para dibujar la letra o, pero esta vez omitiré la linea superior, siendo el n umero introducido
	 * por el usuario la altura y tambien la anchura de la linea inferior.
	 */

	public static void main(String[] args) {
			
		
        Scanner sc = new Scanner(System.in);
		// Pido al usuario que introduzca un caracter no alfanumerico
		System.out.println("Por favor, introduzca un caracter no alfanumerico: ");
		String caracter = sc.next();
		
		// Pido al usuario que introduzca un primer numero entero positivo e impar
		System.out.println("Por favor, introduzca un numero mayor o igual que 9: ");
		int num = sc.nextInt();
		
		//Comprobamos que el numero introducido es mayor que 9
		if (num < 9) {
			System.out.println("ERROR. El numero debe de ser mayor o igual que 9.");
			sc.close();
			return;
		}
		//Declaramos un array con las letras que podemos dibujar
        String[] letras = {"E", "T", "I", "P", "H", "L", "V", "D", "A", "O", "U"};
        
        
        //Mostramos las letras al usuario
        for (int i = 0; i < letras.length ; i++) {
            System.out.println((i + 1) + "- " + letras[i]);
        }
        
        //Pedimos al usuario que introduzca la letra a dibujar
        System.out.println("Introduce una letra a dibujar: ");
        String dibujoLetras = sc.next();
		
		
		switch (dibujoLetras) {
		
        case "E":
        	DibujarE(caracter, num);
            break;
        case "T":
        	DibujarT(caracter, num);
            break;
        case "I":
        	DibujarI(caracter, num);
            break;
        case "P":
        	DibujarP(caracter, num);
            break;
        case "H":
        	DibujarH(caracter, num);
            break;
        case "L":
        	DibujarL(caracter, num);
        	break;
        case "V":
        	DibujarV(caracter, num);
        	break;
        case "D":
        	DibujarD(caracter, num);
        	break;
        case "A":
        	DibujarA(caracter, num);
        	break;
        case "O":
        	DibujarO(caracter, num);
        	break;
        case "U":
        	DibujarU(caracter, num);
        	break;
        	
        	default: 
        		System.out.println("La letra introducida no es válida.");
		}
	}
	public static void DibujarE(String caracter, int num) {	
		
		//Verifica si la altura es par o impar y ajustar la anchura
		int anchura;
		if (num % 2 == 0) {
		    //Si la altura es par, se le suma 1 a la anchura
		    anchura = num + 1;
		} else {
		    //Si la altura es impar, se usa la anchura igual a la altura (num)
		    anchura = num;
		}

		//Creamos el bucle for
		for (int i = 0; i < num; i++) {
		    //Y adjuntamos otro bucle
		    for (int j = 0; j < anchura; j++) {
		        //Condiciones para imprimir el caracter o espacio en blanco
		        if (j == 0 || i == 0 || i == num / 2 || i == num - 1) {
		            //Imprimir el caracter en las posiciones específicas
		            System.out.print(caracter);
		        } else {
		            //Imprimir dos espacios en blanco en otras posiciones
		            System.out.print("  ");
		        }
		    }
		    //Siguiente linea despues de cada fila
		    System.out.println();
		}
	}
	
	public static void DibujarT(String caracter, int num) {

		 //Creamos el bucle
        for (int i = 0; i < num; i++) {
            for (int j = 0; j < num; j++) {
                //Creamos las condiciones especificas
                if (i == 0 || j == num / 2) {
                    System.out.print(caracter);
                } else {
                    //y añadimos el resto de posiciones
                    System.out.print(" ");
                }
            }
            //linea despues de cada fila
            System.out.println();
        }
	
	}
	
	public static void DibujarI(String caracter, int num) {
	
		// Bucle externo para iterar a través de las filas
		for (int i = 0; i < num; i++) {
		    // Bucle interno para iterar a través de las columnas (num columnas)
		    for (int j = 0; j < num; j++) {
		        // Condiciones para imprimir el carácter o espacio en blanco
		        if (j == num / 2 || i == 0 || i == num - 1) {
		            // Imprimir el carácter en las posiciones específicas
		            System.out.print(caracter);
		        } else {
		            // Imprimir un espacio en blanco en otras posiciones
		            System.out.print(" ");
		        }
		    }
		    // Nueva línea después de cada fila
		    System.out.println();
		}

	}
	public static void DibujarP(String caracter, int num) {
	
		//Si la variable 'num' es par, se le suma 1 para hacerla impar
        if (num % 2 == 0) {
            num++;
        }
        //Bucle para imprimir la primera línea de la T
        for (int i = -1; i < num / 2; i++) {
            System.out.print(caracter);
        }
        System.out.println();

        //Bucle para imprimir las líneas intermedias de la T
        for (int i = 1; i < num / 2; i++) {
            System.out.print(caracter);

            //Anidamos un bucle para imprimir espacios en el medio de la figura
            for (int j = -1; j < num / 2; j++) {
                System.out.print(" ");
            }

            System.out.println(caracter);
        }

        //Bucle para imprimir la ultima linea de la parte de arriba de la figura
        for (int i = -1; i < num / 2; i++) {
            System.out.print(caracter);
        }
        System.out.println();

        //Bucle para imprimir las líneas inferiores de la figura
        for (int i = 1; i < num / 2; i++) {
            System.out.println(caracter);
        }
		
	}

	public static void DibujarH(String caracter, int num) {

		//Creamos los bucles
		for (int i = 0; i < num; i++) {
            for (int j = 0; j < num; j++) {
                //Las varias condiciones que va a tener (or)
                if (j == 0 || j == num - 1 || i == num / 2) {
                    System.out.print(caracter);
                } else {
                    //añadimos el resto de posiciones
                    System.out.print(" ");
                }
            }
            //nueva línea después de cada fila
            System.out.println();
        }
		
	}
	public static void DibujarL(String caracter, int num) {
		
		//bucle (externo)
		for (int i = 0; i < num; i++) {
		    //bucle (interno) 
		    for (int j = 0; j < num; j++) {
		        //condiciones para imprimir el carácter o espacio en blanco (or)
		        if (j == 0 || i == num - 1) {
		            //Imprimir el carácter en las posiciones específicas
		            System.out.print(caracter);
		        } else {
		            //Imprimir un espacio en blanco en otras posiciones
		            System.out.print(" ");
		        }
		    }
		    //linea despuesd e cada fila
		    System.out.println();
		}

    }
		
	
	public static void DibujarV(String caracter, int num){
		
    	for (int i = 0; i < num; i++) {
            //Imprimir espacios antes del primer carácter
            for (int j = 0; j < i; j++)	 {
                System.out.print(" ");
            }
        
            //Imprimir el primer carácter
            System.out.print(caracter);

            //Imprimir espacios entre caracteres
            for (int j = 0; j < 2 * (num - i - 1) - 1; j++) {
                System.out.print(" ");
            }

            //Imprime la ultima fila
            if (i < num - 1) {
                System.out.println(caracter);
            } else {
                System.out.println();
            }
    	}
	}
	public static void DibujarD(String caracter, int num) {

		//Parte superior
        for (int i = 0; i < num-num/9; i++) {
            System.out.print(caracter);
        }
        System.out.println();
        //Lineas intermedias
        for (int i = 1; i < num - 1; i++) {
            System.out.print(caracter);

            for (int j = 1; j < num; j++) {
                System.out.print(" ");
            }

            System.out.println(caracter);
        }
        //Parte inferior
        for (int i = 0; i < num-num/9; i++) {
            System.out.print(caracter);
        }
        System.out.println();	
        
	}
	public static void DibujarA(String caracter, int num) {
	
		//Parte superior de la letra A
		for (int i = 0; i < num; i++) {
		    //Espacios antes del vertice izquierdo
		    for (int j = 0; j < num - i - 1; j++) {
		        System.out.print(" ");
		    }
		    // Caracteres que forman la parte superior de la letra 
		    for (int j = 0; j < i * 2 + 1; j++) {
		        if (j == 0 || j == i * 2 || i == num / 2 + 1) {
		            System.out.print(caracter); //Ambos vertices
		        } else {
		            System.out.print(" "); //Espacios en el medio
		        }
		    }

		    System.out.println(); //Nueva línea después de cada fila
		}
	}
	public static void DibujarO(String caracter, int num) {
	
		//bucle externo
		 for (int i = 0; i < num; i++) {
			 	//Bucle interno
	            for (int j = 0; j < num; j++) {
	                //Con esta logica verificamos si estamos en el borde o en el centro y usamos OR
	                if (i == 0 || i == num - 1 || j == 0 || j == num - 1) {
	                    System.out.print(caracter);
	                } else {
	                    System.out.print(" ");
	                }
	            }
	            System.out.println(); //añadimos la linea despues de cada fila
	        }
		
	}
	public static void DibujarU(String caracter, int num) {
		
		//bucle externo
		 for (int i = 0; i < num; i++) {
			 	//bucle interno
	            for (int j = 0; j < num; j++) {
	                //verificamos en que parte estamos
	                if (j == 0 || j == num - 1 || i == num - 1) {
	                    System.out.print(caracter);
	                } else {
	                    System.out.print(" ");
	                }
	            }
	            //linea despues de cada fila
	            System.out.println();
	        }
	
	
	}
}


