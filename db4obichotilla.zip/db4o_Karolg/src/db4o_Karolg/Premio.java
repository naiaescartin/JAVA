package db4o_Karolg;

public class Premio {

	private int id_premio;
    private String nombre_premio;
    private String categoria;
    private int año;
    private String resultado;
    
	public Premio(int id_premio, String nombre_premio, String categoria, int año, String resultado) {
		super();
		this.id_premio = id_premio;
		this.nombre_premio = nombre_premio;
		this.categoria = categoria;
		this.año = año;
		this.resultado = resultado;
	}

	public int getId_premio() {
		return id_premio;
	}

	public void setId_premio(int id_premio) {
		this.id_premio = id_premio;
	}

	public String getNombre_premio() {
		return nombre_premio;
	}

	public void setNombre_premio(String nombre_premio) {
		this.nombre_premio = nombre_premio;
	}

	public String getCategoria() {
		return categoria;
	}

	public void setCategoria(String categoria) {
		this.categoria = categoria;
	}

	public int getAño() {
		return año;
	}

	public void setAño(int año) {
		this.año = año;
	}

	public String getResultado() {
		return resultado;
	}

	public void setResultado(String resultado) {
		this.resultado = resultado;
	}
	
	@Override
	public String toString() {
	    return "Premio: " + nombre_premio + " (" + categoria + ", " + año + ", " + resultado + ")";
	}
    	
}
