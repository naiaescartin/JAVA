package db4o_Karolg;

public class Colaboracion {

	private int id_colaboracion;
    private int num_colaboraciones;
    private CancionTop id_cancion;
    
	public Colaboracion(int id_colaboracion, int num_colaboraciones, CancionTop id_cancion) {
		super();
		this.id_colaboracion = id_colaboracion;
		this.num_colaboraciones = num_colaboraciones;
		this.id_cancion = id_cancion;
	}

	public int getId_colaboracion() {
		return id_colaboracion;
	}

	public void setId_colaboracion(int id_colaboracion) {
		this.id_colaboracion = id_colaboracion;
	}

	public int getNum_colaboraciones() {
		return num_colaboraciones;
	}

	public void setNum_colaboraciones(int num_colaboraciones) {
		this.num_colaboraciones = num_colaboraciones;
	}

	public CancionTop getId_cancion() {
		return id_cancion;
	}

	public void setId_cancion(CancionTop id_cancion) {
		this.id_cancion = id_cancion;
	}
	@Override
	public String toString() {
	    return "Colaboración: " + id_colaboracion + " (Número de colaboraciones: " + num_colaboraciones + ")";
	}  
}
