import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Font;
import javax.swing.JCheckBox;
import javax.swing.ButtonGroup;
import javax.swing.JButton;

public class Jugar extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private final ButtonGroup buttonGroup = new ButtonGroup();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Jugar frame = new Jugar();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Jugar() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 0, 0));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("Votar un contrato");
		lblNewLabel_1.setForeground(new Color(255, 255, 255));
		lblNewLabel_1.setFont(new Font("Segoe Script", Font.BOLD, 11));
		lblNewLabel_1.setBounds(25, 11, 127, 13);
		contentPane.add(lblNewLabel_1);
		
		JCheckBox chckbxNewCheckBox = new JCheckBox("");
		buttonGroup.add(chckbxNewCheckBox);
		chckbxNewCheckBox.setFont(new Font("Segoe Script", Font.BOLD, 10));
		chckbxNewCheckBox.setBounds(50, 67, 21, 21);
		contentPane.add(chckbxNewCheckBox);
		chckbxNewCheckBox.setOpaque(false);
		
		JCheckBox chckbxNewCheckBox_1 = new JCheckBox("");
		buttonGroup.add(chckbxNewCheckBox_1);
		chckbxNewCheckBox_1.setFont(new Font("Segoe Script", Font.BOLD, 10));
		chckbxNewCheckBox_1.setBounds(214, 54, 21, 21);
		contentPane.add(chckbxNewCheckBox_1);
		chckbxNewCheckBox_1.setOpaque(false);
		
		JCheckBox chckbxNewCheckBox_2 = new JCheckBox("");
		buttonGroup.add(chckbxNewCheckBox_2);
		chckbxNewCheckBox_2.setFont(new Font("Segoe Script", Font.BOLD, 10));
		chckbxNewCheckBox_2.setBounds(74, 145, 21, 21);
		contentPane.add(chckbxNewCheckBox_2);
		chckbxNewCheckBox_2.setOpaque(false);
		
		JCheckBox chckbxNewCheckBox_3 = new JCheckBox("");
		chckbxNewCheckBox_3.setFont(new Font("Segoe Script", Font.BOLD, 10));
		chckbxNewCheckBox_3.setBounds(214, 54, 21, 21);
		contentPane.add(chckbxNewCheckBox_3);
		chckbxNewCheckBox_3.setOpaque(false);
		
		JCheckBox chckbxNewCheckBox_4 = new JCheckBox("");
		buttonGroup.add(chckbxNewCheckBox_4);
		chckbxNewCheckBox_4.setFont(new Font("Segoe Script", Font.BOLD, 10));
		chckbxNewCheckBox_4.setBounds(293, 54, 21, 21);
		contentPane.add(chckbxNewCheckBox_4);
		chckbxNewCheckBox_4.setOpaque(false);

		
		JCheckBox chckbxNewCheckBox_5 = new JCheckBox("");
		buttonGroup.add(chckbxNewCheckBox_5);
		chckbxNewCheckBox_5.setFont(new Font("Segoe Script", Font.BOLD, 10));
		chckbxNewCheckBox_5.setBounds(366, 85, 21, 21);
		contentPane.add(chckbxNewCheckBox_5);
		chckbxNewCheckBox_5.setOpaque(false);

		
		JCheckBox chckbxNewCheckBox_6 = new JCheckBox("");
		buttonGroup.add(chckbxNewCheckBox_6);
		chckbxNewCheckBox_6.setFont(new Font("Segoe Script", Font.BOLD, 10));
		chckbxNewCheckBox_6.setBounds(233, 216, 21, 21);
		contentPane.add(chckbxNewCheckBox_6);
		chckbxNewCheckBox_6.setOpaque(false);

		
		JCheckBox chckbxNewCheckBox_7 = new JCheckBox("");
		buttonGroup.add(chckbxNewCheckBox_7);
		chckbxNewCheckBox_7.setFont(new Font("Segoe Script", Font.BOLD, 10));
		chckbxNewCheckBox_7.setBounds(347, 157, 21, 21);
		contentPane.add(chckbxNewCheckBox_7);
		chckbxNewCheckBox_7.setOpaque(false);

		
		JCheckBox chckbxNewCheckBox_8 = new JCheckBox("");
		buttonGroup.add(chckbxNewCheckBox_8);
		chckbxNewCheckBox_8.setFont(new Font("Segoe Script", Font.BOLD, 10));
		chckbxNewCheckBox_8.setBounds(130, 54, 21, 21);
		contentPane.add(chckbxNewCheckBox_8);
		chckbxNewCheckBox_8.setOpaque(false);

		
		JCheckBox chckbxNewCheckBox_5_1 = new JCheckBox("");
		buttonGroup.add(chckbxNewCheckBox_5_1);
		chckbxNewCheckBox_5_1.setFont(new Font("Segoe Script", Font.BOLD, 10));
		chckbxNewCheckBox_5_1.setBounds(130, 181, 21, 21);
		contentPane.add(chckbxNewCheckBox_5_1);
		chckbxNewCheckBox_5_1.setOpaque(false);

		
		JCheckBox chckbxNewCheckBox_5_2 = new JCheckBox("");
		buttonGroup.add(chckbxNewCheckBox_5_2);
		chckbxNewCheckBox_5_2.setFont(new Font("Segoe Script", Font.BOLD, 10));
		chckbxNewCheckBox_5_2.setBounds(214, 123, 21, 21);
		contentPane.add(chckbxNewCheckBox_5_2);
		chckbxNewCheckBox_5_2.setOpaque(false);

		
		JCheckBox chckbxNewCheckBox_5_3 = new JCheckBox("");
		buttonGroup.add(chckbxNewCheckBox_5_3);
		chckbxNewCheckBox_5_3.setFont(new Font("Segoe Script", Font.BOLD, 10));
		chckbxNewCheckBox_5_3.setBounds(194, 201, 21, 21);
		contentPane.add(chckbxNewCheckBox_5_3);
		chckbxNewCheckBox_5_3.setOpaque(false);

		
		JCheckBox chckbxNewCheckBox_5_4 = new JCheckBox("");
		buttonGroup.add(chckbxNewCheckBox_5_4);
		chckbxNewCheckBox_5_4.setFont(new Font("Segoe Script", Font.BOLD, 10));
		chckbxNewCheckBox_5_4.setBounds(50, 201, 21, 21);
		contentPane.add(chckbxNewCheckBox_5_4);
		chckbxNewCheckBox_5_4.setOpaque(false);

		
		JCheckBox chckbxNewCheckBox_5_5 = new JCheckBox("");
		buttonGroup.add(chckbxNewCheckBox_5_5);
		chckbxNewCheckBox_5_5.setFont(new Font("Segoe Script", Font.BOLD, 10));
		chckbxNewCheckBox_5_5.setBounds(293, 201, 21, 21);
		contentPane.add(chckbxNewCheckBox_5_5);
		chckbxNewCheckBox_5_5.setOpaque(false);

		
		JCheckBox chckbxNewCheckBox_5_6 = new JCheckBox("");
		buttonGroup.add(chckbxNewCheckBox_5_6);
		chckbxNewCheckBox_5_6.setFont(new Font("Segoe Script", Font.BOLD, 10));
		chckbxNewCheckBox_5_6.setBounds(378, 181, 21, 21);
		contentPane.add(chckbxNewCheckBox_5_6);
		chckbxNewCheckBox_5_6.setOpaque(false);

		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\Naia\\Downloads\\seleccionmapa2.png"));
		lblNewLabel.setBounds(10, 34, 411, 216);
		contentPane.add(lblNewLabel);
		
		JButton btnNewButton = new JButton("Jugar");
		btnNewButton.setFont(new Font("Segoe Script", Font.BOLD, 11));
		btnNewButton.setBounds(324, 6, 85, 21);
		contentPane.add(btnNewButton);
	}

}