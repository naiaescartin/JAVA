import java.awt.EventQueue;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class UnJugador extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    UnJugador frame = new UnJugador();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public UnJugador() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 450, 300);
        contentPane = new JPanel();
        contentPane.setBackground(new Color(0, 0, 0));
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lblNewLabel = new JLabel("Un jugador");
        lblNewLabel.setForeground(new Color(255, 255, 255));
        lblNewLabel.setFont(new Font("Segoe Script", Font.BOLD, 16));
        lblNewLabel.setBounds(169, 10, 116, 65);
        contentPane.add(lblNewLabel);

        JButton btnSalir = new JButton("Salir");
        btnSalir.setFont(new Font("Segoe Script", Font.BOLD, 12));
        btnSalir.setBounds(307, 225, 99, 17);
        contentPane.add(btnSalir);

        JButton btnJugar = new JButton("Jugar");
        btnJugar.setFont(new Font("Segoe Script", Font.BOLD, 13));
        btnJugar.setBounds(169, 182, 99, 25);
        contentPane.add(btnJugar);

        JButton btnTienda = new JButton("Tienda");
        btnTienda.setFont(new Font("Segoe Script", Font.BOLD, 12));
        btnTienda.setBounds(307, 203, 99, 17);
        contentPane.add(btnTienda);

        JButton btnInventario = new JButton("Inventario");
        btnInventario.setFont(new Font("Segoe Script", Font.BOLD, 12));
        btnInventario.setBounds(307, 176, 99, 17);
        contentPane.add(btnInventario);
        
        JLabel lblNewLabel_1 = new JLabel("New label");
        lblNewLabel_1.setIcon(new ImageIcon("C:\\Users\\Naia\\Downloads\\Captura de pantalla 2024-12-05 102039 (1).png"));
        lblNewLabel_1.setBounds(156, 36, 124, 136);
        contentPane.add(lblNewLabel_1);
        
        JLabel lblNewLabel_2 = new JLabel("New label");
        lblNewLabel_2.setIcon(new ImageIcon("C:\\Users\\Naia\\Downloads\\81PKOcxidaL._AC_UF894,1000_QL80_ (1).jpg"));
        lblNewLabel_2.setBounds(10, 62, 416, 191);
        contentPane.add(lblNewLabel_2);

        btnSalir.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose(); 
                Seleccion seleccion = new Seleccion();
                seleccion.setVisible(true); 
            }
        });

        
        btnTienda.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose(); 
                Tienda tienda = new Tienda();
                tienda.setVisible(true); 
            }
        });
        
        btnJugar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose(); 
                Jugar jugar = new Jugar();
                jugar.setVisible(true); 
            }
        });

     
        btnInventario.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose(); 
                Tienda tienda = new Tienda();
                tienda.setVisible(true); 
            }
        });
    }
}
