package db4o_Karolg;

public class RedSocial {

	private int id_red_social;
    private String plataforma;
    private int seguidores;
    
	public RedSocial(int id_red_social, String plataforma, int seguidores) {
		super();
		this.id_red_social = id_red_social;
		this.plataforma = plataforma;
		this.seguidores = seguidores;
	}

	public int getId_red_social() {
		return id_red_social;
	}

	public void setId_red_social(int id_red_social) {
		this.id_red_social = id_red_social;
	}

	public String getPlataforma() {
		return plataforma;
	}

	public void setPlataforma(String plataforma) {
		this.plataforma = plataforma;
	}

	public int getSeguidores() {
		return seguidores;
	}

	public void setSeguidores(int seguidores) {
		this.seguidores = seguidores;
	}
	@Override
	public String toString() {
	    return "Red Social: " + plataforma + " (Seguidores: " + seguidores + ")";
	}	
}
