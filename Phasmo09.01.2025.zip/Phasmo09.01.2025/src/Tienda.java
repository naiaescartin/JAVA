import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTabbedPane;
import java.awt.Color;
import javax.swing.JButton;
import javax.swing.JLabel;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;
import javax.swing.JProgressBar;
import javax.swing.JSpinner;

public class Tienda extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private final JPanel panel = new JPanel();

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Tienda frame = new Tienda();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    
    private void addClickIncrementListener(JProgressBar progressBar) {
    }

   

    public Tienda() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 450, 300);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

        setContentPane(contentPane);
        contentPane.setLayout(null);
        
        JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
        tabbedPane.setBounds(0, 0, 436, 263);
        contentPane.add(tabbedPane);
        
        
        Font nuevaFuente = new Font("Segoe Script", Font.BOLD, 13);
        tabbedPane.setFont(nuevaFuente);
        
        panel.setBackground(new Color(0, 0, 0));
        tabbedPane.addTab("Tienda", null, panel, null);
        panel.setLayout(null);
        
        JButton btnNewButton = new JButton("Salir");
        btnNewButton.setFont(new Font("Segoe Script", Font.BOLD, 10));
        btnNewButton.setBounds(336, 183, 85, 21);
        panel.add(btnNewButton);
        
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose(); 
                Seleccion seleccion = new Seleccion();
                seleccion.setVisible(true); 
            }
        });
        
        JLabel lblNewLabel = new JLabel("???? €");
        lblNewLabel.setForeground(new Color(255, 255, 255));
        lblNewLabel.setFont(new Font("Segoe Script", Font.BOLD, 14));
        lblNewLabel.setBounds(362, 10, 69, 32);
        panel.add(lblNewLabel);
        
        JLabel lblNewLabel_1 = new JLabel("Crucifijo");
        lblNewLabel_1.setFont(new Font("Segoe Script", Font.BOLD, 10));
        lblNewLabel_1.setForeground(new Color(255, 255, 255));
        lblNewLabel_1.setBounds(242, 112, 69, 13);
        panel.add(lblNewLabel_1);
        
        JLabel lblEMF = new JLabel("EMF");
        lblEMF.setFont(new Font("Segoe Script", Font.BOLD, 10));
        lblEMF.setForeground(new Color(255, 255, 255));
        lblEMF.setBounds(163, 52, 69, 13);
        panel.add(lblEMF);

        JLabel lblSpiritBox = new JLabel("Spirit Box");
        lblSpiritBox.setFont(new Font("Segoe Script", Font.BOLD, 10));
        lblSpiritBox.setForeground(new Color(255, 255, 255));
        lblSpiritBox.setBounds(242, 164, 69, 13);
        panel.add(lblSpiritBox);

        JLabel lblUltravioleta = new JLabel("Ultravioleta");
        lblUltravioleta.setFont(new Font("Segoe Script", Font.BOLD, 10));
        lblUltravioleta.setForeground(new Color(255, 255, 255));
        lblUltravioleta.setBounds(242, 52, 69, 13);
        panel.add(lblUltravioleta);

        JLabel lblLibro = new JLabel("Libro");
        lblLibro.setFont(new Font("Segoe Script", Font.BOLD, 10));
        lblLibro.setForeground(new Color(255, 255, 255));
        lblLibro.setBounds(163, 112, 69, 13);
        panel.add(lblLibro);

        JLabel lblCamaraVideo = new JLabel("Cámara Video");
        lblCamaraVideo.setFont(new Font("Segoe Script", Font.BOLD, 10));
        lblCamaraVideo.setForeground(new Color(255, 255, 255));
        lblCamaraVideo.setBounds(38, 52, 90, 13);
        panel.add(lblCamaraVideo);

        JLabel lblCamaraFotos = new JLabel("Cámara Fotos");
        lblCamaraFotos.setFont(new Font("Segoe Script", Font.BOLD, 10));
        lblCamaraFotos.setForeground(new Color(255, 255, 255));
        lblCamaraFotos.setBounds(38, 112, 90, 13);
        panel.add(lblCamaraFotos);

        JLabel lblIncienso = new JLabel("Incienso");
        lblIncienso.setFont(new Font("Segoe Script", Font.BOLD, 10));
        lblIncienso.setForeground(new Color(255, 255, 255));
        lblIncienso.setBounds(38, 164, 69, 13);
        panel.add(lblIncienso);

        JLabel lblVela = new JLabel("Vela");
        lblVela.setFont(new Font("Segoe Script", Font.BOLD, 10));
        lblVela.setForeground(new Color(255, 255, 255));
        lblVela.setBounds(163, 164, 69, 13);
        panel.add(lblVela);


        
        JLabel lblNewLabel_2 = new JLabel("Seleccione el objeto que quiera comprar");
        lblNewLabel_2.setFont(new Font("Segoe Script", Font.BOLD, 10));
        lblNewLabel_2.setVerticalAlignment(SwingConstants.BOTTOM);
        lblNewLabel_2.setForeground(new Color(255, 255, 255));
        lblNewLabel_2.setBounds(26, 10, 273, 22);
        panel.add(lblNewLabel_2);
        
        JSpinner spinner = new JSpinner();
        spinner.setBounds(62, 75, 30, 13);
        panel.add(spinner);
        
        JSpinner spinner_1 = new JSpinner();
        spinner_1.setBounds(163, 75, 30, 13);
        panel.add(spinner_1);
        
        JSpinner spinner_2 = new JSpinner();
        spinner_2.setBounds(252, 75, 30, 13);
        panel.add(spinner_2);
        
        JSpinner spinner_3 = new JSpinner();
        spinner_3.setBounds(62, 135, 30, 13);
        panel.add(spinner_3);
        
        JSpinner spinner_4 = new JSpinner();
        spinner_4.setBounds(163, 135, 30, 13);
        panel.add(spinner_4);
        
        JSpinner spinner_5 = new JSpinner();
        spinner_5.setBounds(252, 135, 30, 13);
        panel.add(spinner_5);
        
        JSpinner spinner_6 = new JSpinner();
        spinner_6.setBounds(62, 186, 30, 13);
        panel.add(spinner_6);
        
        JSpinner spinner_7 = new JSpinner();
        spinner_7.setBounds(163, 186, 30, 13);
        panel.add(spinner_7);
        
        JSpinner spinner_8 = new JSpinner();
        spinner_8.setBounds(252, 186, 30, 13);
        panel.add(spinner_8);
        
        JPanel panel_2 = new JPanel();
        tabbedPane.addTab("                                                   ", null, panel_2, null);
        panel_2.setBackground(new Color(0, 0, 0));
        tabbedPane.setEnabledAt(1, false);
        
        JPanel panel_1 = new JPanel();
        panel_1.setBackground(new Color(0, 0, 0));
        tabbedPane.addTab("Inventario", null, panel_1, null);
        panel_1.setLayout(null);
        
        JButton btnNewButton_1 = new JButton("Salir");
        btnNewButton_1.setFont(new Font("Segoe Script", Font.BOLD, 10));
        btnNewButton_1.setBounds(336, 182, 85, 21);
        panel_1.add(btnNewButton_1);
        
        
        btnNewButton_1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose(); 
                Seleccion seleccion = new Seleccion();
                seleccion.setVisible(true); 
            }
        });
        
        JLabel lblNewLabel_10 = new JLabel("Crucifijo");
        lblNewLabel_10.setFont(new Font("Segoe Script", Font.BOLD, 10));
        lblNewLabel_10.setForeground(new Color(255, 255, 255));
        lblNewLabel_10.setBounds(242, 112, 69, 13);
        panel_1.add(lblNewLabel_10);

        JLabel lblNewLabel_11 = new JLabel("EMF");
        lblNewLabel_11.setFont(new Font("Segoe Script", Font.BOLD, 10));
        lblNewLabel_11.setForeground(new Color(255, 255, 255));
        lblNewLabel_11.setBounds(163, 52, 69, 13);
        panel_1.add(lblNewLabel_11);

        JLabel lblNewLabel_12 = new JLabel("Spirit Box");
        lblNewLabel_12.setFont(new Font("Segoe Script", Font.BOLD, 10));
        lblNewLabel_12.setForeground(new Color(255, 255, 255));
        lblNewLabel_12.setBounds(242, 164, 69, 13);
        panel_1.add(lblNewLabel_12);

        JLabel lblNewLabel_13 = new JLabel("Ultravioleta");
        lblNewLabel_13.setFont(new Font("Segoe Script", Font.BOLD, 10));
        lblNewLabel_13.setForeground(new Color(255, 255, 255));
        lblNewLabel_13.setBounds(242, 52, 69, 13);
        panel_1.add(lblNewLabel_13);

        JLabel lblNewLabel_14 = new JLabel("Libro");
        lblNewLabel_14.setFont(new Font("Segoe Script", Font.BOLD, 10));
        lblNewLabel_14.setForeground(new Color(255, 255, 255));
        lblNewLabel_14.setBounds(163, 112, 69, 13);
        panel_1.add(lblNewLabel_14);

        JLabel lblNewLabel_15 = new JLabel("Cámara Video");
        lblNewLabel_15.setFont(new Font("Segoe Script", Font.BOLD, 10));
        lblNewLabel_15.setForeground(new Color(255, 255, 255));
        lblNewLabel_15.setBounds(38, 52, 90, 13);
        panel_1.add(lblNewLabel_15);

        JLabel lblNewLabel_16 = new JLabel("Cámara Fotos");
        lblNewLabel_16.setFont(new Font("Segoe Script", Font.BOLD, 10));
        lblNewLabel_16.setForeground(new Color(255, 255, 255));
        lblNewLabel_16.setBounds(38, 112, 90, 13);
        panel_1.add(lblNewLabel_16);

        JLabel lblNewLabel_17 = new JLabel("Incienso");
        lblNewLabel_17.setFont(new Font("Segoe Script", Font.BOLD, 10));
        lblNewLabel_17.setForeground(new Color(255, 255, 255));
        lblNewLabel_17.setBounds(38, 164, 69, 13);
        panel_1.add(lblNewLabel_17);

        JLabel lblNewLabel_18 = new JLabel("Vela");
        lblNewLabel_18.setFont(new Font("Segoe Script", Font.BOLD, 10));
        lblNewLabel_18.setForeground(new Color(255, 255, 255));
        lblNewLabel_18.setBounds(163, 164, 69, 13);
        panel_1.add(lblNewLabel_18);
        
        JProgressBar progressBar = new JProgressBar();
        progressBar.setStringPainted(true);
        progressBar.setBounds(38, 182, 69, 11);
        panel_1.add(progressBar);
        
        JProgressBar progressBar_1 = new JProgressBar();
        progressBar_1.setStringPainted(true);
        progressBar_1.setBounds(143, 182, 69, 11);
        panel_1.add(progressBar_1);
        
        JProgressBar progressBar_2 = new JProgressBar();
        progressBar_2.setStringPainted(true);
        progressBar_2.setBounds(242, 182, 69, 11);
        panel_1.add(progressBar_2);
        
        JProgressBar progressBar_3 = new JProgressBar();
        progressBar_3.setStringPainted(true);
        progressBar_3.setBounds(38, 135, 69, 11);
        panel_1.add(progressBar_3);
        
        JProgressBar progressBar_4 = new JProgressBar();
        progressBar_4.setStringPainted(true);
        progressBar_4.setBounds(143, 135, 69, 11);
        panel_1.add(progressBar_4);
        
        JProgressBar progressBar_5 = new JProgressBar();
        progressBar_5.setStringPainted(true);
        progressBar_5.setBounds(242, 135, 69, 11);
        panel_1.add(progressBar_5);
        
        JProgressBar progressBar_6 = new JProgressBar();
        progressBar_6.setStringPainted(true);
        progressBar_6.setBounds(242, 75, 69, 11);
        panel_1.add(progressBar_6);
        
        JProgressBar progressBar_7 = new JProgressBar();
        progressBar_7.setStringPainted(true);
        progressBar_7.setBounds(143, 75, 69, 11);
        panel_1.add(progressBar_7);
        
        JProgressBar progressBar_7_1 = new JProgressBar();
        progressBar_7_1.setStringPainted(true);
        progressBar_7_1.setBounds(38, 75, 69, 11);
        panel_1.add(progressBar_7_1);
        addClickIncrementListener(progressBar);
        addClickIncrementListener(progressBar_1);
        addClickIncrementListener(progressBar_2);
        addClickIncrementListener(progressBar_3);
        addClickIncrementListener(progressBar_4);
        addClickIncrementListener(progressBar_5);
        addClickIncrementListener(progressBar_6);
        addClickIncrementListener(progressBar_7);
        addClickIncrementListener(progressBar_7_1);
        
        JLabel lblNewLabel_3 = new JLabel("New label");
        lblNewLabel_3.setBounds(336, 10, 45, 13);
        panel_1.add(lblNewLabel_3);
        
        JLabel lblNewLabel_4 = new JLabel("???? €");
        lblNewLabel_4.setForeground(Color.WHITE);
        lblNewLabel_4.setFont(new Font("Segoe Script", Font.BOLD, 14));
        lblNewLabel_4.setBounds(352, 10, 69, 32);
        panel_1.add(lblNewLabel_4);

        
        
        
    

    }
}
