package db4o_Karolg;

import java.util.Date;
import java.util.List;

public class Gira {
    private int id_gira;
    private String nombre;
    private Date fecha_inicio;
    private Date fecha_fin;
    private int num_conciertos;
    private List<Album> albums;
    
	public Gira(int id_gira, String nombre, Date fecha_inicio, Date fecha_fin, int num_conciertos, List<Album> albums) {
		super();
		this.id_gira = id_gira;
		this.nombre = nombre;
		this.fecha_inicio = fecha_inicio;
		this.fecha_fin = fecha_fin;
		this.num_conciertos = num_conciertos;
		this.albums = albums;
	}

	public int getId_gira() {
		return id_gira;
	}

	public void setId_gira(int id_gira) {
		this.id_gira = id_gira;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public Date getFecha_inicio() {
		return fecha_inicio;
	}

	public void setFecha_inicio(Date fecha_inicio) {
		this.fecha_inicio = fecha_inicio;
	}

	public Date getFecha_fin() {
		return fecha_fin;
	}

	public void setFecha_fin(Date fecha_fin) {
		this.fecha_fin = fecha_fin;
	}

	public int getNum_conciertos() {
		return num_conciertos;
	}

	public void setNum_conciertos(int num_conciertos) {
		this.num_conciertos = num_conciertos;
	}

	public List<Album> getAlbums() {
		return albums;
	}

	public void setAlbums(List<Album> albums) {
		this.albums = albums;
	}
	
	@Override
	public String toString() {
	    return "Gira: " + nombre + " (Inicio: " + fecha_inicio + ", Fin: " + fecha_fin + ", Conciertos: " + num_conciertos + ")";
	}
}